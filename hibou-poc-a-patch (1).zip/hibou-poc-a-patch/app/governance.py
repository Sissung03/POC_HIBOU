# governance.py
# Confidence Governance Engine — version POC.
# T = f(R, I, Rev), indépendant de C (invariant dT/dC = 0).
# A = h(T, C) — brouillon de travail, voir Document Technique v0, Partie 5.
# Statut : hypothèse de travail, non calibré.

from .config import (
    T_WEIGHTS, T_BINS, C_ACT_THRESHOLD_LOW_T, C_ACT_THRESHOLD_MID_T,
    C_ACT_THRESHOLD_HIGH_T, STOP_CONFIDENCE_STATES,
)


def compute_T(R, I, Rev):
    """Première forme concrète de T = f(R, I, Rev). Ne dépend jamais de C."""
    t = (
        T_WEIGHTS["R"] * R
        + T_WEIGHTS["I"] * I
        + T_WEIGHTS["REV_COMPLEMENT"] * (1 - Rev)
    )
    return min(1.0, max(0.0, t))


def decide_action(T, C, confidence_state=None):
    """A = h(T, C). C influence toujours le comportement, sauf quand la
    pipeline de confiance elle-même a échoué (voir ci-dessous).

    Critère STOP-vs-ESCALATE — VALIDÉ le 26 sept. 2026 (Denard), ÉTENDU
    le 28 sept. 2026 (tranché par Cooper sur délégation de Denard, à
    revoir avec Roqia lors de la calibration) : si le Confidence State est
    UNKNOWN ou CONFLICTED (hard gate G ou D), il n'y a rien de fiable à
    transmettre — STOP immédiat, QUEL QUE SOIT T. Symétrie avec
    l'invariant d'indépendance : de même que T ne dépend pas de C, ce
    critère ne dépend pas de T. Le rationnel "demander un arbitrage humain
    sur du bruit n'a pas de sens" vaut à tout niveau de risque, pas
    seulement au palier maximal.

    Au palier maximal avec un State connu (même dégradé), une base réelle
    existe pour un arbitrage humain → ESCALATE. Jamais ACT/VERIFY/RECOMMEND
    au palier maximal (invariant de prudence, Manifeste HIBOU-OS, Partie IX).
    """
    if confidence_state in STOP_CONFIDENCE_STATES:
        return "STOP"

    if T >= T_BINS["maximal"]:
        return "ESCALATE"

    if T >= T_BINS["eleve"]:
        return "ACT" if C >= C_ACT_THRESHOLD_HIGH_T else "RECOMMEND"

    if T >= T_BINS["modere"]:
        return "ACT" if C >= C_ACT_THRESHOLD_MID_T else "VERIFY"

    return "ACT" if C >= C_ACT_THRESHOLD_LOW_T else "VERIFY"

# compute_confidence.py
# Implémentation de la fonction constitutionnelle FCSV — version POC.
# Statut : hypothèse de travail (voir Document Technique v0, Partie 4).

import math

from .config import ALPHA_WEIGHTS, STATE_CAP, THRESHOLDS, GATE_EPSILON

EPS = 1e-6


def normalize_value(dim, raw, spec):
    """Ramène un indicateur brut à [0, 1] pour une dimension du CSV.

    raw peut être :
      - un scalaire 0-4 (échelle ordinale — voir Manifeste, Partie VIII :
        "De l'échelle ordinale à l'échelle continue")
      - un dict d'indicateurs bruts propres à la dimension Q
      - un dict générique {"value": float} déjà normalisé
    """
    if raw is None:
        return 0.0

    if isinstance(raw, (int, float)):
        # Ancrage ordinal -> continu : 0,1,2,3,4 -> 0.00,0.25,0.50,0.75,1.00
        return max(0.0, min(1.0, raw / 4.0))

    if dim == "Q":
        signed = raw.get("signed", False)
        p = 1.0 if signed else float(raw.get("trust_score", 0.5))
        freshness = math.exp(-spec.get("lambda", 0.00002778) * raw.get("age_seconds", 0))
        completeness = raw.get("present", 0) / max(1, raw.get("required", 1))
        snr = raw.get("snr", 1.0)
        snr_score = 1.0 / (1.0 + math.exp(-(snr - spec.get("snr_mid", 1.0))))
        return min(1.0, 0.25 * p + 0.25 * freshness + 0.25 * completeness + 0.25 * snr_score)

    if "value" in raw:
        return max(0.0, min(1.0, float(raw["value"])))

    return 0.0


def normalize_csv(csv_raw, normalize_spec):
    csv_norm = {}
    for dim in ["Q", "D", "K", "X", "E", "S", "M", "G"]:
        raw = csv_raw.get(dim)
        spec = normalize_spec.get(dim, {})
        csv_norm[dim] = normalize_value(dim, raw, spec)
    return csv_norm


def compute_confidence_state(csv_norm):
    """Hard gates — évaluées avant toute agrégation numérique (non-compensation
    stricte). Voir Manifeste HIBOU-OS, Partie VIII.

    Les gates "zéro" utilisent <= GATE_EPSILON (et non == 0.0) : une
    égalité flottante stricte ratait silencieusement le gate dès qu'une
    source continue renvoyait un epsilon au lieu d'un zéro exact —
    fail-open sur le gate de sécurité le plus critique.
    G rejoint Q/K/X dans les dimensions fondamentales du gate DEGRADED :
    un G quasi nul mais non nul (ex: 0.1) ne doit pas donner STABLE.
    """
    Q, D, K, X, E, S, M, G = (
        csv_norm["Q"], csv_norm["D"], csv_norm["K"], csv_norm["X"],
        csv_norm["E"], csv_norm["S"], csv_norm["M"], csv_norm["G"],
    )

    if G <= GATE_EPSILON:
        return "UNKNOWN"
    if D <= GATE_EPSILON:
        return "CONFLICTED"
    if (Q < THRESHOLDS["fundamental_low"] or K < THRESHOLDS["fundamental_low"]
            or X < THRESHOLDS["fundamental_low"] or G < THRESHOLDS["fundamental_low"]):
        return "DEGRADED"
    if S < THRESHOLDS["fragile"] or E < THRESHOLDS["fragile"] or M < THRESHOLDS["fragile"]:
        return "FRAGILE"
    if all(v >= THRESHOLDS["robust"] for v in [Q, D, K, X, E, S, M, G]):
        return "ROBUST"
    return "STABLE"


def geometric_aggregation(csv_norm, alpha):
    """Moyenne géométrique pondérée — pénalise les dimensions faibles,
    limite la compensation excessive entre dimensions.
    Exige sum(alpha.values()) == 1.0 (garanti par config.py ; testé dans
    test_alpha_weights_sum_to_one) : sinon C est biaisé d'un exposant
    égal à la somme des poids."""
    log_sum = 0.0
    for d, w in alpha.items():
        v = max(csv_norm.get(d, 0.0), EPS)
        log_sum += w * math.log(v)
    return math.exp(log_sum)


def FCSV(csv_raw, normalize_spec):
    csv_norm = normalize_csv(csv_raw, normalize_spec)
    state = compute_confidence_state(csv_norm)
    c_raw = geometric_aggregation(csv_norm, ALPHA_WEIGHTS)
    c_cap = STATE_CAP[state]
    c = min(c_raw, c_cap)
    return {
        "csv_norm": csv_norm,
        "state": state,
        "c_raw": c_raw,
        "c": c,
        "c_cap": c_cap,
    }

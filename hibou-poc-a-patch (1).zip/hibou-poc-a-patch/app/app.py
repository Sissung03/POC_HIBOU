# app.py — Façade Kernel minimale.
# Point d'entrée unique : voir Document Technique v0, Partie 2
# (submit_decision_context — le seul contrat exposé aux applications).

import os

import yaml
from flask import Flask, jsonify, request

from .compute_confidence import FCSV
from .governance import compute_T, decide_action
from .storage import DecisionStore

app = Flask(__name__)

_spec_path = os.path.join(os.path.dirname(__file__), "normalize_spec.yaml")
with open(_spec_path, "r") as f:
    NORMALIZE_SPEC = yaml.safe_load(f)

store = DecisionStore()


@app.route("/compute_confidence", methods=["POST"])
def compute_confidence():
    payload = request.get_json(force=True)
    csv_raw = payload.get("csv_raw", {})
    result = FCSV(csv_raw, NORMALIZE_SPEC)
    return jsonify(result)


@app.route("/submit_decision_context", methods=["POST"])
def submit_decision_context():
    payload = request.get_json(force=True)
    context = payload.get("context", {})
    R = float(payload.get("R", 0.0))
    I = float(payload.get("I", 0.0))
    Rev = float(payload.get("Rev", 1.0))
    csv_raw = payload.get("csv_raw", {})

    conf = FCSV(csv_raw, NORMALIZE_SPEC)
    T = compute_T(R, I, Rev)
    C = conf["c"]
    A = decide_action(T, C, confidence_state=conf["state"])

    decision_id = store.save_decision(context, conf, R, I, Rev, T, A)

    return jsonify({
        "A": A,
        "C": C,
        "State": conf["state"],
        "T": T,
        "confidence_report": conf,
        "decision_id": decision_id,
    })


@app.route("/outcome", methods=["POST"])
def outcome():
    """Relie un résultat observé à une décision tracée — canal 1 de vérité
    terrain (Document Technique v0, Partie 7) : le monde répond.
    N'ajuste jamais T ou les hard gates en direct : alimente seulement
    SCI-MEM pour un cycle de recalibration gouverné, périodique et audité."""
    payload = request.get_json(force=True)
    decision_id = payload.get("decision_id")
    outcome_value = payload.get("outcome")  # SUCCESS | FAIL | PARTIAL
    metrics = payload.get("metrics", {})
    horizon = payload.get("horizon", "IMMEDIAT")  # IMMEDIAT | COURT_DELAI | LONG_DELAI
    notes = payload.get("notes")

    if not decision_id or not outcome_value:
        return jsonify({"error": "decision_id et outcome sont requis"}), 400

    updated = store.save_outcome(decision_id, outcome_value, metrics, horizon, notes)
    if not updated:
        return jsonify({"error": "decision_id introuvable"}), 404

    return jsonify({"decision_id": decision_id, "verdict_status": "OBSERVE", "acknowledged": True})


REVIEW_VERDICTS = {"CONFIRME", "CORRIGE"}
ARBITRATION_RESOLUTIONS = {"ACT", "STOP", "MODIFIE", "DELEGUE"}
ARBITRATION_AGREEMENTS = {"ACCORD", "DESACCORD_PARTIEL", "DESACCORD"}


@app.route("/review", methods=["POST"])
def review():
    """Canal 2 de vérité terrain : revue experte offline d'une décision.
    L'expert juge le *processus* (State et A étaient-ils corrects ?),
    indépendamment du résultat observé — une bonne décision peut échouer
    par malchance et inversement. Plusieurs experts peuvent revoir la
    même décision. N'ajuste jamais rien en direct : alimente SCI-MEM pour
    la matrice de confusion expert-vs-système du protocole de calibration.
    """
    payload = request.get_json(force=True)
    decision_id = payload.get("decision_id")
    reviewer = payload.get("reviewer")
    state_verdict = payload.get("state_verdict")
    action_verdict = payload.get("action_verdict")

    if not decision_id or not reviewer or not state_verdict or not action_verdict:
        return jsonify({"error": "decision_id, reviewer, state_verdict et action_verdict sont requis"}), 400
    if state_verdict not in REVIEW_VERDICTS or action_verdict not in REVIEW_VERDICTS:
        return jsonify({"error": "state_verdict et action_verdict ∈ {CONFIRME, CORRIGE}"}), 400

    review_id = store.save_review(
        decision_id, reviewer, state_verdict, payload.get("state_corrected"),
        action_verdict, payload.get("action_corrected"),
        payload.get("r_assessment"), payload.get("i_assessment"),
        payload.get("rev_assessment"), payload.get("notes"),
    )
    if review_id is None:
        return jsonify({"error": "decision_id introuvable"}), 404
    return jsonify({"review_id": review_id, "decision_id": decision_id, "acknowledged": True}), 201


@app.route("/arbitration", methods=["POST"])
def arbitration():
    """Canal 3 de vérité terrain : résolution humaine d'une décision que
    HIBOU a escaladée, vérifiée ou arrêtée. Enregistre ce que l'humain a
    finalement décidé et son accord avec le cadrage de HIBOU — c'est la
    mesure d'alignement de la couche de gouvernance elle-même.
    N'ajuste jamais rien en direct : alimente SCI-MEM pour la calibration.
    """
    payload = request.get_json(force=True)
    decision_id = payload.get("decision_id")
    resolver = payload.get("resolver")
    resolution = payload.get("resolution")
    agreement = payload.get("agreement")

    if not decision_id or not resolver or not resolution or not agreement:
        return jsonify({"error": "decision_id, resolver, resolution et agreement sont requis"}), 400
    if resolution not in ARBITRATION_RESOLUTIONS:
        return jsonify({"error": "resolution ∈ {ACT, STOP, MODIFIE, DELEGUE}"}), 400
    if agreement not in ARBITRATION_AGREEMENTS:
        return jsonify({"error": "agreement ∈ {ACCORD, DESACCORD_PARTIEL, DESACCORD}"}), 400

    record = store.get_decision(decision_id)
    if record is None:
        return jsonify({"error": "decision_id introuvable"}), 404

    store.save_arbitration(
        decision_id, resolver, record["action"], resolution,
        payload.get("resolution_detail"), agreement,
        payload.get("latency_seconds"), payload.get("notes"),
    )
    return jsonify({"decision_id": decision_id, "acknowledged": True})


@app.route("/decision/<decision_id>", methods=["GET"])
def get_decision(decision_id):
    """Récupère le DecisionRecord complet — traçabilité et audit.
    Inclut les 3 canaux de vérité terrain : outcome, reviews, arbitration."""
    record = store.get_decision(decision_id)
    if record is None:
        return jsonify({"error": "decision_id introuvable"}), 404
    return jsonify(record)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)

import os
import tempfile

import pytest

os.environ["HIBOU_DB"] = tempfile.mktemp(suffix=".db")

from app.app import app  # noqa: E402


@pytest.fixture
def client():
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def _submit(client, R=0.95, I=1.0, Rev=0.0):
    """Soumet une décision à risque maximal -> ESCALATE (d-0001-like)."""
    resp = client.post("/submit_decision_context", json={
        "context": {"scenario": "paiement_irreversible"},
        "R": R, "I": I, "Rev": Rev,
        "csv_raw": {d: 4 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]},
    })
    assert resp.status_code == 200
    return resp.get_json()["decision_id"]


def test_review_roundtrip(client):
    decision_id = _submit(client)
    resp = client.post("/review", json={
        "decision_id": decision_id,
        "reviewer": "Roqia",
        "state_verdict": "CONFIRME",
        "action_verdict": "CORRIGE",
        "action_corrected": "STOP",
        "notes": "ESCALATE correct mais STOP aurait été plus prudent vu le montant.",
    })
    assert resp.status_code == 201
    data = resp.get_json()
    assert data["acknowledged"] is True
    assert "review_id" in data

    record = client.get(f"/decision/{decision_id}").get_json()
    assert len(record["reviews"]) == 1
    review = record["reviews"][0]
    assert review["reviewer"] == "Roqia"
    assert review["action_verdict"] == "CORRIGE"
    assert review["action_corrected"] == "STOP"


def test_review_multiple_reviewers(client):
    decision_id = _submit(client)
    for reviewer in ["Roqia", "Denard"]:
        resp = client.post("/review", json={
            "decision_id": decision_id, "reviewer": reviewer,
            "state_verdict": "CONFIRME", "action_verdict": "CONFIRME",
        })
        assert resp.status_code == 201
    record = client.get(f"/decision/{decision_id}").get_json()
    assert len(record["reviews"]) == 2


def test_review_unknown_decision_returns_404(client):
    resp = client.post("/review", json={
        "decision_id": "does-not-exist", "reviewer": "Roqia",
        "state_verdict": "CONFIRME", "action_verdict": "CONFIRME",
    })
    assert resp.status_code == 404


def test_review_invalid_verdict_returns_400(client):
    decision_id = _submit(client)
    resp = client.post("/review", json={
        "decision_id": decision_id, "reviewer": "Roqia",
        "state_verdict": "PEUT-ETRE", "action_verdict": "CONFIRME",
    })
    assert resp.status_code == 400


def test_review_missing_fields_returns_400(client):
    resp = client.post("/review", json={"decision_id": "x"})
    assert resp.status_code == 400


def test_arbitration_roundtrip_on_escalated_decision(client):
    decision_id = _submit(client)  # A = ESCALATE attendu
    record = client.get(f"/decision/{decision_id}").get_json()
    assert record["action"] == "ESCALATE"

    resp = client.post("/arbitration", json={
        "decision_id": decision_id,
        "resolver": "Denard",
        "resolution": "STOP",
        "resolution_detail": "Montant trop élevé pour un vendredi soir.",
        "agreement": "ACCORD",
        "latency_seconds": 95,
    })
    assert resp.status_code == 200
    assert resp.get_json()["acknowledged"] is True

    record = client.get(f"/decision/{decision_id}").get_json()
    arb = record["arbitration"]
    assert arb is not None
    assert arb["resolver"] == "Denard"
    assert arb["hibou_action"] == "ESCALATE"
    assert arb["resolution"] == "STOP"
    assert arb["agreement"] == "ACCORD"


def test_arbitration_unknown_decision_returns_404(client):
    resp = client.post("/arbitration", json={
        "decision_id": "does-not-exist", "resolver": "Denard",
        "resolution": "STOP", "agreement": "ACCORD",
    })
    assert resp.status_code == 404


def test_arbitration_invalid_values_return_400(client):
    decision_id = _submit(client)
    resp = client.post("/arbitration", json={
        "decision_id": decision_id, "resolver": "Denard",
        "resolution": "PEUT-ETRE", "agreement": "ACCORD",
    })
    assert resp.status_code == 400
    resp = client.post("/arbitration", json={
        "decision_id": decision_id, "resolver": "Denard",
        "resolution": "STOP", "agreement": "BOF",
    })
    assert resp.status_code == 400


def test_get_decision_aggregates_all_three_channels(client):
    decision_id = _submit(client)
    client.post("/outcome", json={"decision_id": decision_id, "outcome": "SUCCESS"})
    client.post("/review", json={
        "decision_id": decision_id, "reviewer": "Roqia",
        "state_verdict": "CONFIRME", "action_verdict": "CONFIRME",
    })
    client.post("/arbitration", json={
        "decision_id": decision_id, "resolver": "Denard",
        "resolution": "ACT", "agreement": "DESACCORD_PARTIEL",
    })
    record = client.get(f"/decision/{decision_id}").get_json()
    assert record["outcome"] == "SUCCESS"
    assert len(record["reviews"]) == 1
    assert record["arbitration"]["resolution"] == "ACT"

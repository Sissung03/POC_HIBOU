# Protocole de calibration HIBOU-OS — Cycle 1

> **Statut : brouillon à revoir.** Basé sur les définitions de dimensions
> validées (`docs/dimensions_csv.md`, validé le 28 sept. 2026) et les
> points tranchés dans `docs/decisions_a_trancher.md` (à valider avant de
> calibrer — on ne calibre pas un comportement qui va changer).

## 0. Principes constitutionnels (non négociables, jamais calibrés)

Ces invariants ne sont pas des paramètres : ils ne se "règlent" pas.

- Hard gates évalués **avant** toute agrégation (non-compensation stricte).
- Invariant `C ≤ Cap(State)` — plafonnement par état.
- `T = f(R, I, Rev)` **indépendant** de C (dT/dC = 0, vérifié par test).
- Palier maximal (T ≥ 0,9) : sorties admissibles = {STOP, ESCALATE} uniquement.
- `/outcome` n'ajuste **jamais** T, les gates ou les poids en direct :
  il alimente SCI-MEM pour un cycle de recalibration gouverné.

Tout le reste (poids, seuils, plafonds, bornes de T, seuils C) est calibrable.

## 1. Objectif du cycle 1

Passer des "ancrages initiaux" à des paramètres empiriquement fondés sur
des décisions **réelles** tracées via SCI-MEM. Objectif modeste et explicite :
réduire l'arbitraire et mesurer la cohérence — pas atteindre une vérité absolue.

## 2. Prérequis (bloquants avant toute collecte)

1. Tableau des dimensions validé (`docs/dimensions_csv.md`) — ✅ fait le 28 sept. 2026.
2. ~~`docs/decisions_a_trancher.md` §1 (SEEK) et §2 (UNKNOWN/CONFLICTED à T
   non maximal) tranchés~~ — ✅ tranchés le 28 sept. 2026 (implémentés +
   testés ; à revoir avec Roqia en calibration).
3. ~~Définir les 2 autres canaux de vérité terrain (le PoC n'implémente que
   `/outcome`)~~ — ✅ fait le 28 sept. 2026 : `/review` (canal 2, revue
   experte) et `/arbitration` (canal 3, résolution humaine), implémentés +
   testés, voir `docs/canaux_verite_terrain.md`.

## 3. Collecte — tracer des décisions réelles (SCI-MEM)

- **Périmètre pilote :** 1 à 2 cas d'usage à enjeu modéré à élevé, où une
  mauvaise décision a un coût observable (ex : validation de paiement,
  modération de contenu sensible). Pas de cas jouet : la calibration
  n'est valable que pour la distribution sur laquelle on l'a faite.
- **Instrumentation :** toute décision passe par `/submit_decision_context`
  avec R, I, Rev renseignés par l'opérateur au moment de la décision
  (pas reconstruits après coup).
- **Vérité terrain (3 canaux) :** chaque décision reçoit un outcome via
  `/outcome` avec son horizon (IMMEDIAT / COURT_DELAI / LONG_DELAI) ; un
  échantillon stratifié reçoit des reviews via `/review` ; chaque décision
  non-ACT reçoit sa résolution via `/arbitration`. Voir
  `docs/canaux_verite_terrain.md`.
- **Cible :** ~150 décisions pour le cycle 1, avec stratification visée
  sur les 6 états (idéalement ≥ 15 par état). Si certains états sont
  introuvables en réel, le noter explicitement comme biais de couverture
  plutôt que de forcer avec du synthétique.
- **Gel du dataset :** export JSON immuable et versionné
  (`dataset_calib_v1.json`, hash noté dans le journal d'audit).
  On ne calibre jamais sur un jeu qu'on modifie en cours de route.

## 4. Métriques — calculées hors-ligne, jamais en prod

Sur le dataset gelé :

1. **Distributions** : états, C, C_raw vs C (effet du plafonnement), T, A.
   Le dashboard Streamlit existant couvre déjà une partie — l'étendre
   avec T et A si besoin.
2. **Pouvoir prédictif de C** : taux de SUCCESS par bande de C et par état.
   Si les décisions à C élevé n'ont pas plus de succès que celles à C
   faible, les poids ou les seuils sont à revoir.
3. **Revue experte (le cœur du cycle 1)** : échantillon stratifié d'environ
   30 décisions revu par Denard + Roqia, en aveugle du système si possible :
   - le State était-il juste ?
   - A (ACT/VERIFY/RECOMMEND/ESCALATE/STOP) était-il la bonne sortie ?
   - R, I, Rev renseignés étaient-ils bien évalués ?
   → matrice de confusion "expert vs système", avec verbatims.
4. **Faux positifs/négatifs des gates** : ex. UNKNOWN alors que la donnée
   existait (normalisateur trop strict), ou STABLE alors qu'un expert voit
   une lacune critique (gate trop laxiste).
5. **Sensibilité aux seuils** : décisions à T proche des bornes
   (0,4 / 0,7 / 0,9) — combien basculeraient si la borne bougeait de ±0,05 ?
   Si beaucoup, la borne est fragile et doit être justifiée ou déplacée.

## 5. Ajustements — ordre et discipline

**Ordre recommandé** (de l'amont vers l'aval du pipeline) :

1. `THRESHOLDS` et `STATE_CAP` d'abord — effet direct sur les états ;
2. `ALPHA_WEIGHTS` (rapports relatifs) ensuite ;
3. `T_WEIGHTS`, `T_BINS`, seuils `C_ACT_*` en dernier — ce sont eux qui
   gouvernent l'action, donc le réglage le plus sensible.

**Règles :**

- Un cycle = un jeu de paramètres proposé (diff versionné `config v1.0 → v1.1`).
- Chaque changement est justifié par une mesure chiffrée
  (ex : "relever `fragile` de 0,50 à 0,55 réduit les FRAGILE faux positifs
  de 22 % à 9 % sur l'échantillon expert").
- **Interdit** : ajuster sur le dataset puis re-mesurer le succès sur ce
  même dataset sans jeu de confirmation. Le jeu de confirmation = nouvelles
  décisions tracées *après* l'ajustement (c'est le cycle 2).
- Les rapports relatifs entre poids ne changent que sur justification
  experte, pas sur bruit statistique (n=150 reste petit).

## 6. Gouvernance du changement

- Paramètres versionnés dans `config.py`, journal d'audit tenu à jour :
  qui / quand / quoi / pourquoi / sur quelles données (hash du dataset).
- Validation : Denard + Roqia signent le diff avant déploiement.
- Déploiement : redémarrage versionné du service, jamais d'ajustement
  en temps réel. Version précédente conservée avec rejeu possible sur
  le dataset gelé (rollback + audit).
- Toute modification ultérieure repart du §4 sur de nouvelles données.

## 7. Critères de sortie du cycle 1

Le cycle 1 est terminé quand :

- [ ] les 6 états ont été observés au moins une fois en réel
      (ou le biais de couverture est documenté) ;
- [ ] l'accord expert-système sur l'échantillon revu est ≥ 80 %
      (seuil proposé, à valider) ;
- [ ] l'analyse de sensibilité (§4.5) ne montre pas de falaise
      (pas de borne où ±0,05 fait basculer > 15 % des décisions) ;
- [ ] le rapport de calibration (1 page : données, changements,
      justifications, limites connues) est signé.

## 8. Après le cycle 1

- **Cycle 2** : nouvelles décisions réelles → jeu de confirmation.
  On mesure, on ne réajuste pas sur le cycle 1.
- Seulement après un cycle 2 stable : élargissement à un nouveau cas
  d'usage (nouvelle distribution = nouvelle calibration partielle).

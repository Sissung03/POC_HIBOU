# Les 3 canaux de vérité terrain (SCI-MEM)

> Le Document Technique v0, Partie 7, prévoit 3 canaux de feedback. Le PoC
> n'implémentait que le premier. Les canaux 2 et 3 ci-dessous sont
> **reconstruits à partir de l'architecture** (le Document Technique v0 ne
> fait pas partie des sources partagées) — s'il les définit différemment,
> aligner ce document et le code sur lui.

## Principe commun (constitutionnel)

Les 3 canaux **écrivent** dans SCI-MEM. Aucun n'ajuste **jamais** T, les
hard gates, les poids ou les seuils en direct. Ils alimentent uniquement
la traçabilité pour un cycle de recalibration gouverné, périodique et
audité (voir `docs/protocole_calibration.md`). C'est ce qui sépare
l'apprentissage (offline, gouverné) de l'exécution (temps réel, gelée).

## Canal 1 — Outcome : le monde répond (existant)

`POST /outcome` → `{decision_id, outcome: SUCCESS|FAIL|PARTIAL, metrics, horizon, notes}`

- **Question :** que s'est-il réellement passé après la décision ?
- **Quand :** dès que le résultat est observable (horizon IMMEDIAT, COURT_DELAI ou LONG_DELAI).
- **Rôle en calibration :** mesure du pouvoir prédictif de C (les décisions
  à C élevé ont-elles plus de succès ?).

## Canal 2 — Review : l'expert juge le processus (nouveau)

`POST /review` → `{decision_id, reviewer, state_verdict: CONFIRME|CORRIGE, [state_corrected], action_verdict: CONFIRME|CORRIGE, [action_corrected], [r_assessment, i_assessment, rev_assessment], [notes]}`

- **Question :** la décision était-elle *bonne*, indépendamment du résultat ?
  Une bonne décision peut échouer par malchance ; une mauvaise peut réussir
  par chance. Le résultat ne juge pas le processus.
- **Quand :** offline, sur échantillon stratifié (~30 décisions par cycle),
  en aveugle du système si possible. Plusieurs experts peuvent revoir la
  même décision (désaccords inter-experts = signal en soi).
- **Rôle en calibration :** c'est **l'instrument central du cycle 1** —
  la matrice de confusion expert-vs-système (State juste ? A juste ?
  R/I/Rev bien évalués ?). Voir protocole §4.3.

## Canal 3 — Arbitration : l'humain tranche les escalades (nouveau)

`POST /arbitration` → `{decision_id, resolver, resolution: ACT|STOP|MODIFIE|DELEGUE, [resolution_detail], agreement: ACCORD|DESACCORD_PARTIEL|DESACCORD, [latency_seconds], [notes]}`

- **Question :** face à une décision escaladée / vérifiée / arrêtée par
  HIBOU, qu'a finalement fait l'humain — et était-il d'accord avec le
  cadrage de HIBOU ?
- **Quand :** en ligne, exhaustif pour les décisions non-ACT (chaque
  ESCALATE/STOP/VERIFY devrait recevoir sa résolution).
- **Rôle en calibration :** mesure d'alignement de la **couche de
  gouvernance elle-même**. Si les humains résolvent systématiquement
  en DESACCORD avec le cadrage, les seuils de T ou les bandes sont à
  revoir. La latence d'arbitrage mesure aussi le coût opérationnel de
  l'escalade (trop d'escalades lentes = seuils trop prudents ?).

## Lecture croisée (exemple)

Une décision `ESCALATE` résolue `STOP` en `ACCORD` avec un outcome
`SUCCESS` (le non-paiement a évité une fraude) : le système a bien
cadré, l'humain a bien tranché, le monde a confirmé. Les 3 canaux
racontent 3 histoires complémentaires — aucune ne suffit seule.

## Futur — canal 4 : vérification prédictive

Quand SCI-02 (moteur de prédiction/trajectoire) existera : comparer les
trajectoires prédites au réel observé. C'est le feedback du *diagnostic*,
là où l'outcome est le feedback de *l'action* et la review celui du
*processus*. Non implémenté à ce stade — noté pour ne pas l'oublier.

## Schéma de synthèse

| Canal | Endpoint | Qui parle | Question | Temporalité |
|-------|----------|-----------|----------|-------------|
| 1 Outcome | `/outcome` | le monde | que s'est-il passé ? | à l'observation |
| 2 Review | `/review` | l'expert | la décision était-elle bonne ? | offline, échantillonné |
| 3 Arbitration | `/arbitration` | l'humain en boucle | qu'as-tu décidé face à l'escalade ? | en ligne, exhaustif |
